package com.github.dan.NoStorageRestrict;

public class Constants {

    public static final String DOCUMENTSUI_PACKAGE_NAME = "com.android.documentsui";

    public static final String DOCUMENTSUI_GOOGLE_PACKAGE_NAME = "com.google.android.documentsui";
    public static final String STORAGEMANAGER_NAME = "com.android.externalstorage";

}